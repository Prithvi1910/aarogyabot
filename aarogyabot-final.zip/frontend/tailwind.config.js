/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#f0fdf4',   // Light mint
          100: '#dcfce7',
          500: '#22c55e',  // Green-based health theme
          600: '#16a34a',
          700: '#15803d',
        }
      }
    },
  },
  plugins: [],
}
